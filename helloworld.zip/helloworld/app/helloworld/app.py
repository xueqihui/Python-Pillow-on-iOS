"""
My first application
"""
import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW
from toga import App

#from OpenSSL import *
from PIL import Image,ImageFile,ImageFilter
from PIL import BmpImagePlugin
from PIL import JpegImagePlugin
import io
#import requests as req
from io import BytesIO
from PIL import ImageEnhance,ImageDraw
import sys
import os
from pathlib import Path
from toga_iOS import Paths as currentp
from toga_iOS import ImagePickerView, ImageView
import toga_iOS.widgets.imagepickerview as ipcl
from toga_iOS.libs import NSURL, NSData, UIImage, UIImagePickerController,UIImageView
from rubicon.objc.api import ObjCInstance
from rubicon.objc import objc_method
import rubicon.objc.types
from toga_iOS.libs import UIImagePickerController, NSURL, NSURLRequest, UIViewController, UIImagePickerControllerOriginalImage,uikit,NSData
import math
from rubicon.objc.types import Array,array_for_sequence
import struct
import ctypes

iv=None
im=None  #UIImage
main_box=None
main_window =None
img = None #PIL image

data =None #NSData
button1=None
button2=None
AlbumImage =None
buf =None

gdata = NSData.data()



class TogaImagePickerView(UIImagePickerController):

    @property
    def window(self):
        return self._window

    def _init_(self,window):
        self._window=window



    @objc_method
    def imagePickerController_didFinishPickingMediaWithInfo_(self, sender, info) -> None:
    
        global im,data,buf,img
        global iv,main_box,main_window,button2,button1,AlbumImage
    
        #print("return from album")
        #pass
        #if self.interface.on_webview_load:
        #    self.interface.on_webview_load(self.interface)
        self.dismissViewControllerAnimated(False,completion=None)
        #global AlbumImage
        AlbumImage=info[UIImagePickerControllerOriginalImage]
        size = AlbumImage.size
        scale = AlbumImage.scale
        imagewidth = math.floor(size.width*scale)
        imageheight = math.floor(size.height*scale)
        print(AlbumImage)

        data =  ObjCInstance(uikit.UIImageJPEGRepresentation(AlbumImage,0))
        #print(data)

        buf=ctypes.create_string_buffer(data.length)
        ctypes.memmove(ctypes.byref(buf), data.bytes , data.length)
        img=Image.open(io.BytesIO(buf))
        #enh_con = ImageEnhance.Contrast(img)
        #contrast = 1.5
        #img = enh_con.enhance(contrast)

        imgByteArr = io.BytesIO()
        img.save(imgByteArr,format='bmp')
        imgByteArr = imgByteArr.getvalue()

        im = toga.Image(path=None,data=imgByteArr,uiimage=None)
        iv.image=im
        iv.refresh()

        
        
    @objc_method
    def imagePickerController_imagePickerControllerDidCancel_(self) -> None:
        _self.dismiss(animated=False,completion=None)






class HelloWorld(toga.App):

    def startup(self):
        global main_box
        main_box = toga.Box(style=Pack(direction=COLUMN))
        """
        name_label = toga.Label(
            'Your name: ',
            style=Pack(padding=(0, 5))
        )
        """
        """ following are test purpose for PIL
        #Image.register_open("py",JpegImagePlugin.JpegImageFile)
        #Image.register_extension("py", ".py")
        img = Image.new( 'RGB', (100,100), "red") # Create a new black image
        pixels = img.load() # Create the pixel map
        for i in range(100):    # For every pixel:
            for j in range(100):
                pixels[i,j] = 100 # Set the colour accordingly
        w,h= img.size
        print('Original image size: %sx%s' % (w, h))
        name_label = toga.Label(
            'Original image size: ' + str(w)+'X'+str(h),
            style=Pack(padding=(0, 5))
        )
        self.name_input = toga.TextInput(style=Pack(flex=1))
        
        name_box = toga.Box(style=Pack(direction=ROW, padding=5))
        name_box.add(name_label)
        name_box.add(self.name_input)
        
        #response = req.get('http://39.107.26.59/pictures/20190521091516.jpg_150.jpeg')
        #image = Image.open()
        #img_box.add()
        #image = Image.open('http://39.107.26.59/pictures/20190521091516.jpg_800.jpeg')
        #print(image.tobitmap())
        img.show()

        enh = ImageEnhance.Contrast(img)
        enh.enhance(1.3).show("30% more contrast")

        #ibin=img.fromarray(pixels).tobytes()
        #input_image = BmpImagePlugin. ("1.jpg")
        #image_data = input_image.tobytes()
        dir= str(Path(sys.modules[App.app.module_name].__file__).parent)
        #dir = currentp.app
        print ("path=" + dir)

        img=Image.open (dir+'/1.jpeg').filter(ImageFilter.BLUR)
        enh_con = ImageEnhance.Contrast(img)
        contrast = 1.5
        img = enh_con.enhance(contrast)

        imgByteArr = io.BytesIO()
        img.save(imgByteArr,format='bmp')
        imgByteArr = imgByteArr.getvalue()
        
        
        global im
        im = toga.Image(path=None,data=imgByteArr,uiimage=None)
        """
        #Image._show(img)
        #im = toga.Image("1.jpg",data=None)
        #im._show(im)
        #img=im.imgByteArr
        global iv
        iv = toga.ImageView(None)
        iv.image=None
        
        global button1,button2
        
        
        button1 = toga.Button(
            '选择图片',
            on_press=self.picker_image,
            style=Pack(padding=5)
        )
        button2 = toga.Button(
            '黑白',
            on_press=self.bwconvert,
            style=Pack(padding=5)
        )
        button3 = toga.Button(
            '模糊',
            on_press=self.blurfilter,
            style=Pack(padding=5)
        )
        button4 = toga.Button(
            '找边缘',
            on_press=self.edgefind,
            style=Pack(padding=5)
        )
        button5 = toga.Button(
            '增对比',
            on_press=self.enhance,
            style=Pack(padding=5)
        )
        button6 = toga.Button(
            '直方图',
            on_press=self.histogram,
            style=Pack(padding=5)
        )
        
        comm_box = toga.Box(style=Pack(direction=ROW))
        #main_box.add(name_box)
        main_box.add(button1)
        comm_box.add(button2)
        comm_box.add(button3)
        comm_box.add(button4)
        comm_box.add(button5)
        comm_box.add(button6)
        main_box.add(comm_box)
        main_box.add(iv)


        global main_window
        
        self.main_window = toga.MainWindow(title=self.formal_name)
        self.main_window.content = main_box
        
        self.main_window.show()
        main_window=self.main_window
        
    def enhance(self,widgets):
        global data,iv,im,gdata
        
        enh_con = ImageEnhance.Contrast(img)
        contrast = 1.5
        img1 = enh_con.enhance(contrast)

        imgByteArr = io.BytesIO()
        img1.save(imgByteArr,format='bmp')
        imgByteArr = imgByteArr.getvalue()

        im = toga.Image(path=None,data=imgByteArr,uiimage=None)
        iv.image=im
        iv.refresh()
                 
    def edgefind(self,widgets):
        global data,iv,im,gdata
        

        img1=img.filter(ImageFilter.CONTOUR)

        imgByteArr = io.BytesIO()
        img1.save(imgByteArr,format='bmp')
        imgByteArr = imgByteArr.getvalue()

        im = toga.Image(path=None,data=imgByteArr,uiimage=None)
        iv.image=im
        iv.refresh()
        
    def bwconvert(self,widgets):
        global data,iv,im,gdata
        img1=img.convert('L')

        imgByteArr = io.BytesIO()
        img1.save(imgByteArr,format='bmp')
        imgByteArr = imgByteArr.getvalue()

        im = toga.Image(path=None,data=imgByteArr,uiimage=None)
        iv.image=im
        iv.refresh()
        
        
    def histogram(self,widgets):
        global data,iv,im,gdata
        
        hist = img.histogram()
        maxv = max(hist)
        print(maxv)
        img1 = Image.new( 'RGB', (260,maxv + 50), "white") # Create a new black image)
        with img1:
            draw = ImageDraw.Draw(img1,mode="RGB")
            for i in range(0,255):
                draw.line([i, 0, i, hist[i]], "red",1,None)
            for i in range(256,511):
                draw.line([i-256, 0, i-256 , hist[i]], "green",1,None)
            for i in range(512,767):
                draw.line([i-512, 0, i-512, hist[i]],"blue",1,None)
        img1=img1.transpose(Image.FLIP_TOP_BOTTOM)
        img1= img1.resize((img.size[0],round(img.size[0]*0.6)),resample=Image.NEAREST,box=None,reducing_gap=None)

        imgByteArr = io.BytesIO()
        img1.save(imgByteArr,format='bmp')
        imgByteArr = imgByteArr.getvalue()

        im = toga.Image(path=None,data=imgByteArr,uiimage=None)
        iv.image=im
        iv.refresh()
        
        
    def blurfilter(self,widgets):
        global data,iv,im,gdata
        img1=img.filter(ImageFilter.BLUR)

        imgByteArr = io.BytesIO()
        img1.save(imgByteArr,format='bmp')
        imgByteArr = imgByteArr.getvalue()

        im = toga.Image(path=None,data=imgByteArr,uiimage=None)
        iv.image=im
        iv.refresh()
                    
                    
            
    def picker_image(self, widget):
        #global AlbumImage
        #ipv=ImagePickerView.create(self,self.main_window)
        #im=AlbumImage
        self.picker=TogaImagePickerView.alloc().init(self.main_window)
         #self.picker.picker = window
        self.picker.delegate=self.picker
        self.picker.sourcetype = 0
         #vct=UIViewController.alloc().init()
        self.main_window._impl.controller.presentViewController(self.picker,animated=False,completion=None)

def main():
    return HelloWorld()
