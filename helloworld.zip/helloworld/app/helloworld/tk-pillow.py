#!/usr/bin/python3
# -*- coding: utf-8 -*-

from PIL import Image, ImageTk,ImageFilter
from tkinter import Tk
from tkinter.ttk import Frame, Label
import sys

class Example(Frame):
  
    def __init__(self):
        super().__init__()   
         
        self.loadImage() 
        self.initUI()
        
        
    def loadImage(self):
        try:
            img = Image.open("helloworld/1.jpg")
            size =(200,200)
            img_resize = img.resize(size)
            img_resize.filter(ImageFilter.BLUR)
            img_l=img_resize.convert('L')
            self.img=img_l

        except IOError:
            print("Unable to load image")
            sys.exit(1)
        
    
    def initUI(self):
      
        self.master.title("Label")
        
        tatras = ImageTk.PhotoImage(self.img)
        label = Label(self, image=tatras)
        
        # reference must be stored
        label.image = tatras
        
        label.pack()
        self.pack()
        
        
    def setGeometry(self):
      
        w, h = self.img.size
        self.master.geometry(("%dx%d+300+300") % (w, h))
        

def main():
  
    root = Tk()
    ex = Example()
    ex.setGeometry()
    root.mainloop()  


if __name__ == '__main__':
    main()  