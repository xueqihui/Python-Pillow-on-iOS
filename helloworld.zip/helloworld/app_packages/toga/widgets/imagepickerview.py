from toga.handlers import wrapped_handler

from .base import Widget


class ImagePickerView(Widget):


    def __init__(self, id=None,  factory=None,):
        super().__init__(id=id, factory=factory)

        self._impl = self.factory.ImagePickerView()

   
