from rubicon.objc import objc_method
import rubicon.objc.types

from toga_iOS.libs import UIImagePickerController, NSURL, NSURLRequest, UIViewController, UIImagePickerControllerOriginalImage,uikit,NSData
from toga_iOS.widgets.base import Widget
from rubicon.objc.types import encoding_for_ctype
import toga

import ctypes
from rubicon.objc.api import ObjCInstance
from rubicon.objc.runtime import objc_id
from ctypes import POINTER
from toga_iOS.libs import NSURL, NSData, UIImage
import rubicon.objc.types as types
from rubicon.objc.types import CGFloat

from helloworld import app as myAPP
from pathlib import Path
from io import BytesIO
import io

AlbumImage=None
#data=None

class TogaImagePickerView1(UIImagePickerController):
    
    @property
    def window(self):
        return self._window
    
    def _init_(self,window):
        self._window=window
    
    
    
    @objc_method
    def imagePickerController1_didFinishPickingMediaWithInfo_(self, sender, info) -> None:
        #print("return from album")
        #pass
        #if self.interface.on_webview_load:
        #    self.interface.on_webview_load(self.interface)
        self.dismissViewControllerAnimated(False,completion=None)
        global AlbumImage
        AlbumImage=info[UIImagePickerControllerOriginalImage]
        print(AlbumImage)
        global  data
        types.register_ctype_for_type('cdata',NSData)
        types.register_ctype_for_type('cimage',UIImage)
        #uikit.UIImageJPEGRepresentation.restype = types.ctype_for_type(NSData)
        #uikit.UIImageJPEGRepresentation.argtypes=[objc_id,CGFloat]

        myAPP.data =  ObjCInstance(uikit.UIImageJPEGRepresentation(AlbumImage,1.0))
        print(myAPP.data)
        #NSData(myAPP.data).writeToFile_atomically_("tmp.dat",True)
        
        global im,iv,main_box,main_window,gdata
        #gdata=NSData.alloc().init()
        
        #myAPP.gdata=NSData.dataWithdata(data)
        
        
        #myAPP.im = toga.Image(path=None,data=data)
        
        #toga.ImageView(myAPP.im)
        #myAPP.iv=toga.ImageView(myAPP.im)
        #print(myAPP.gdata)
        #myAPP.iv.container(myAPP.main_box)
        #myAPP.main_box.add(myAPP.iv)
        #myAPP.main_window.show()
        #img = info[UIImagePickerControllerOriginalImage]

        
    @objc_method
    def imagePickerController1_imagePickerControllerDidCancel_(self) -> None:
        _self.dismiss(animated=False,completion=None)
    


class ImagePickerView(Widget):
    def _init_():
        pass
        
    def create(self, window):
        #self.native = ImagePickerView(self)
        #self.native.interface = self.interface
        #self.delegate = self.native.delegate
        self.picker=TogaImagePickerView1.alloc().init(window)
        #self.picker.picker = window
        self.picker.delegate=self.picker
        self.picker.sourcetype = 0
        #vct=UIViewController.alloc().init()
        window._impl.controller.presentViewController(self.picker,animated=False,completion=None)
        #vct.presentViewController(self.picker,animated=False,completion=None)
        # Add the layout constraints
        #self.add_constraints()

  

  
